<footer>
    <link rel="stylesheet" type="text/css" href="../CSS/footer.css">
    <h4>Ferreteria Meissen</h4>
    <div class="enlaces">
        <ul>
                    <li><a href="pqrs.php">Contacto</a></li>
                    <li><a href="nosotros.php">Nosotros</a></li>
                    <li><a href="../Php/index.php">Catalogo</a></li>
                    <li><a href="../Php/pinturas.php">Pintura</a></li>
                    <li><a href="../Php/electricas.php">Electricas</a></li>
                    <li><a href="../Php/herramientas.php">Herramientas</a></li>
                    <li><a href="../Php/accesorios.php">Accesorios</a></li>
                    <li><a href="../Php/carpinteria.php">Carpinteria</a></li>
                    <li><a href="../Php/plomeria.php">Plomeria</a></li>
                    <li><a href="../Php/jardineria.php">Jardineria</a></li>
        </ul>
    </div>
    <h4>Redes sociales</h4>
    <div class="sociales">
    <div class="sociales-link">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-whatsapp"></i></a>
        <p>Derechos de autor &copy; 2023 Ferretería Meissen. Todos los derechos reservados.</p>
    </div>
    </div>
</footer>