<link rel="stylesheet" type="text/css" href="../CSS/menu.css">
<div class="encabezado">
    <header>
        <div class = titulo>
        <h1>FERRETERIA MEISSEN</h1>
        </div>    
        <div class="logo" >
        <img src="../imagenes/ferreteria.jpeg" alt="logo ferreteria">
        </div>
    </header>
    <nav class="navbar">
        <div class="lista">
        <a href="nosotros.php" class="Catalogo">Nosotros</a>
        <a href="index.php" class="Catalogo">Catalogo</a>
        <a href="pinturas.php" class="Pintura">Pintura</a>
        <a href="electricas.php" class="Electricas">Electricas</a>
        <a href="herramientas.php" class="Herramientas_Manuales">Herramientas</a>
        <a href="accesorios.php" class="Accesorios">Accesorios</a>
        <a href="carpinteria.php" class="Accesorios">Carpinteria</a>
        <a href="plomeria.php" class="Accesorios">Plomeria</a>
        <a href="jardineria.php" class="Accesorios">Jardineria</a>
        <button class="btn-login">
            <a class="btn-login"href="loginCliente.php">Acceder</a>
        </button>
        <button class="btn-login">
            <a class="btn-login"href="registroCliente.php">Regístrate</a>
        </button>
        </div>
        </nav>
    </div>
